package ios.safari.pad

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

class SettingsActivity : AppCompatActivity() {
    private lateinit var p: Prefs
    private var scroll: ScrollView? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val barSw = listOf(0xFFFFFFFF, 0xFFE5E5EA, 0xFFFFF4E0, 0xFFFFE4EC, 0xFFDDEEFF, 0xFFDDF5E4, 0xFF2C2C2E, 0xFF000000).map { it.toInt() }
    private val swatches = listOf(0xFF0A84FF, 0xFF30D158, 0xFFFF9F0A, 0xFFFF375F, 0xFFBF5AF2, 0xFF64D2FF, 0xFF8E8E93).map { it.toInt() }

    override fun onCreate(b: Bundle?) { super.onCreate(b); p = Prefs(this); rebuild() }

    private fun label(t: String, top: Int = 14) = TextView(this).apply {
        text = t; textSize = 15f; setTextColor(p.text); setPadding(0, dp(top), 0, dp(4))
    }

    private fun LinearLayout.head(t: String) = addView(TextView(context).apply {
        text = t.uppercase(); textSize = 12f; setTextColor(p.accent); typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, dp(26), 0, dp(2))
    })

    private fun LinearLayout.sw(t: String, k: String, d: Boolean) = addView(Switch(context).apply {
        text = t; textSize = 15f; setTextColor(p.text); isChecked = p.b(k, d); setPadding(0, dp(8), 0, dp(8))
        thumbTintList = ColorStateList.valueOf(p.accent); trackTintList = ColorStateList.valueOf(p.accent and 0x00FFFFFF or 0x66000000)
        setOnCheckedChangeListener { _, v -> p.put(k, v) }
    })

    private fun LinearLayout.slider(t: String, k: String, min: Int, max: Int, d: Int, unit: String = "") {
        val l = label("$t: ${p.i(k, d)}$unit")
        addView(l)
        addView(SeekBar(context).apply {
            this.max = max - min; progress = p.i(k, d) - min
            progressTintList = ColorStateList.valueOf(p.accent); thumbTintList = ColorStateList.valueOf(p.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.put(k, v + min); l.text = "$t: ${v + min}$unit" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun LinearLayout.chips(t: String, k: String, opts: List<String>, d: Int = 0) {
        addView(label(t))
        val row = LinearLayout(context)
        opts.forEachIndexed { i, o ->
            val sel = p.i(k, d) == i
            row.addView(TextView(context).apply {
                text = o; textSize = 14f; gravity = Gravity.CENTER; setPadding(dp(14), dp(8), dp(14), dp(8))
                setTextColor(if (sel) Color.WHITE else p.text)
                background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(if (sel) p.accent else p.pill) }
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8); bottomMargin = dp(4) }
                setOnClickListener { p.put(k, i); rebuild() }
            })
        }
        addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(row) })
    }

    private fun LinearLayout.colors(t: String, k: String, list: List<Int>, def: Int) {
        addView(label(t))
        val row = LinearLayout(context); val curV = p.i(k, def)
        list.forEach { c ->
            row.addView(TextView(context).apply {
                gravity = Gravity.CENTER; textSize = 13f; setTextColor(p.text); text = if (c == 0) "A" else ""
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    if (c != 0) setColor(c)
                    if (curV == c) setStroke(dp(3), p.accent) else setStroke(dp(1), p.sub)
                }
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) }
                setOnClickListener { p.put(k, c); rebuild() }
            })
        }
        addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(row) })
    }

    private fun LinearLayout.btn(t: String, color: Int = p.accent, f: () -> Unit) = addView(TextView(context).apply {
        text = t; textSize = 16f; setTextColor(color); setPadding(0, dp(14), 0, dp(2)); setOnClickListener { f() }
    })

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { saveWallpaper(u); rebuild() } }

    private fun saveWallpaper(u: Uri) {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1; while (maxOf(o.outWidth, o.outHeight) / s > 1600) s *= 2
            val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return
            File(filesDir, "wallpaper.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            p.put("wpStamp", System.currentTimeMillis().toString())
        } catch (_: Exception) { Toast.makeText(this, "Couldn't load that image", Toast.LENGTH_SHORT).show() }
    }

        private fun LinearLayout.edit(t: String, k: String, d: String) {
        addView(label(t))
        addView(EditText(context).apply {
            setText(p.s(k, d)); setTextColor(p.text); textSize = 15f; singleLine()
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(p.pill) }; setPadding(dp(12), dp(10), dp(12), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { p.put(k, e.toString()) }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        })
    }

    private fun EditText.singleLine() { setSingleLine(true) }

    private fun rebuild() {
        val y = scroll?.scrollY ?: 0
        window.statusBarColor = p.bg; window.navigationBarColor = p.bg
        WindowCompat.getInsetsController(window, window.decorView).apply { isAppearanceLightStatusBars = !p.dark; isAppearanceLightNavigationBars = !p.dark }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(48)) }
        col.addView(FrameLayout(this).apply {
            addView(TextView(context).apply { text = "Settings"; textSize = 28f; setTextColor(p.text); typeface = android.graphics.Typeface.DEFAULT_BOLD })
            addView(TextView(context).apply {
                text = "Done"; textSize = 17f; setTextColor(p.accent); setPadding(dp(12), dp(8), 0, dp(8))
                layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL); setOnClickListener { finish() }
            })
        })
        col.head("Appearance")
        col.chips("Theme", "theme", listOf("System", "Light", "Dark"))
        col.colors("Accent color", "accent", swatches, 0xFF0A84FF.toInt())
        col.chips("Font", "font", listOf("Default", "Serif", "Mono"))
        col.chips("Animations", "anim", listOf("Off", "Subtle", "Normal"), 1)
        col.chips("Icon style", "iconStyle", listOf("Safari", "Material"))
        col.head("Colors")
        col.colors("Toolbar color (A = automatic)", "tbColor", listOf(0) + barSw, 0)
        col.colors("Address bar color", "pillColor", listOf(0) + barSw, 0)
        col.colors("Icon color (A = accent)", "iconColor", listOf(0) + swatches, 0)
        col.head("Address bar")
        col.slider("Height", "addrH", 32, 56, 40, "dp")
        col.slider("Corner radius", "radius", 0, 28, 12, "dp")
        col.slider("Text size", "addrSize", 12, 20, 15, "sp")
        col.sw("Center text", "addrCenter", true)
        col.sw("Show lock icon", "lock", true)
        col.sw("Show aA button", "showAa", true)
        col.sw("Show reload button", "showReload", true)
        col.slider("Progress bar thickness", "progH", 1, 6, 2, "dp")
        col.chips("Search engine", "engine", listOf("Google", "DuckDuckGo", "Bing", "Brave"))
        col.head("Toolbar")
        col.chips("Position", "tbPos", listOf("Bottom", "Top"))
        col.slider("Height", "barH", 40, 72, 52, "dp")
        col.sw("Show share button", "showShare", true)
        col.sw("Show new-tab button", "showNew", true)
        col.sw("Hide while scrolling", "autohide", true)
        col.head("Start page")
        col.edit("Title", "startTitle", "Favorites")
        col.sw("Show favorites", "showFavs", true)
        col.slider("Columns", "favCols", 3, 5, 4)
        col.slider("Icon size", "favSize", 44, 80, 60, "dp")
        col.chips("Icon shape", "favShape", listOf("Circle", "Rounded square"))
        col.chips("Background", "startBg", listOf("Plain", "Accent tint"))
        col.btn("Choose wallpaper…") { pick.launch("image/*") }
        col.btn("Remove wallpaper", p.sub) { p.put("wpStamp", ""); File(filesDir, "wallpaper.jpg").delete(); rebuild() }
        col.slider("Wallpaper dimming", "wpDim", 0, 70, 25, "%")
        col.addView(label("Tip: long-press a favorite to edit or delete it, tap + to add one.", 14).apply { textSize = 13f; setTextColor(p.sub) })
        col.btn("Reset favorites", p.sub) { p.sp.edit().remove("favs").apply(); Toast.makeText(this, "Favorites reset", Toast.LENGTH_SHORT).show() }
        col.head("Tabs")
        col.slider("Grid columns", "tabCols", 1, 3, 2)
        col.slider("Preview height", "thumbH", 100, 320, 200, "dp")
        col.head("Web content")
        col.slider("Text size", "zoom", 50, 200, 100, "%")
        col.sw("Request desktop sites", "desktop", false)
        col.sw("JavaScript", "js", true)
        col.addView(TextView(this).apply {
            text = "Reset to defaults"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFFFF453A.toInt())
            setPadding(0, dp(28), 0, 0); setOnClickListener { p.sp.edit().clear().apply(); rebuild() }
        })
        scroll = ScrollView(this).apply { setBackgroundColor(p.bg); fitsSystemWindows = true; addView(col) }
        setContentView(scroll); scroll!!.post { scroll!!.scrollTo(0, y) }
    }
}
