package ios.safari.pad

import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import androidx.core.graphics.ColorUtils

class Prefs(private val c: Context) {
    val sp = c.getSharedPreferences("safari", Context.MODE_PRIVATE)
    fun i(k: String, d: Int) = sp.getInt(k, d)
    fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun s(k: String, d: String) = sp.getString(k, d) ?: d
    fun put(k: String, v: Any) {
        sp.edit().apply { when (v) { is Int -> putInt(k, v); is Boolean -> putBoolean(k, v); is String -> putString(k, v) } }.apply()
    }
    val dark get() = when (i("theme", 0)) {
        1 -> false; 2 -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private fun pick(l: Long, d: Long) = (if (dark) d else l).toInt()
    val accent get() = i("accent", 0xFF0A84FF.toInt())
    val bg get() = pick(0xFFFFFFFF, 0xFF000000)
    val bar get() = pick(0xFFF9F9FB, 0xFF1C1C1E)
    val pill get() = pick(0xFFEEEEF3, 0xFF2C2C2E)
    val text get() = pick(0xFF1C1C1E, 0xFFFFFFFF)
    val over get() = pick(0xFFF2F2F7, 0xFF111113)
    val card get() = pick(0xFFFFFFFF, 0xFF2C2C2E)
    val sub get() = 0xFF8E8E93.toInt()
    /** 0 = off, 1 = subtle (default), 2 = normal */
    val anim get() = when (i("anim", 1)) { 0 -> 0f; 1 -> .6f; else -> 1f }
    fun d(ms: Long) = (ms * anim).toLong()
    fun colorOr(k: String, d: Int) = i(k, 0).let { if (it == 0) d else it }
    fun onColor(c: Int) = if (ColorUtils.calculateLuminance(c) > .5) 0xFF1C1C1E.toInt() else 0xFFFFFFFF.toInt()
    val font: Typeface get() = when (i("font", 0)) { 1 -> Typeface.SERIF; 2 -> Typeface.MONOSPACE; else -> Typeface.DEFAULT }
}
