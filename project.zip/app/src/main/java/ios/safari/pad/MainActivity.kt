package ios.safari.pad

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import android.text.InputType
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import androidx.appcompat.app.AlertDialog
import java.io.File
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class Tab(val web: WebView, var title: String = "Start Page", var isStart: Boolean = true, var thumb: Bitmap? = null)

class MainActivity : AppCompatActivity() {
    private val p by lazy { Prefs(this) }
    private val tabs = mutableListOf<Tab>()
    private var cur = 0
    private val tab get() = tabs[cur]
    private lateinit var container: FrameLayout
    private lateinit var urlField: EditText
    private lateinit var progress: ProgressBar
    private lateinit var startPage: View
    private lateinit var favGrid: GridLayout
    private lateinit var bottomBar: View
    private lateinit var overview: View
    private lateinit var gridRv: RecyclerView
    private lateinit var btnBack: ImageView
    private lateinit var btnForward: ImageView
    private val adapter = TabAdapter()
    private var barsHidden = false
    private var wpStamp = "x"
    private var wpBmp: Bitmap? = null
    private var startFg = 0
    private val barH get() = dp(p.i("barH", 52))
    private val desktopUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    private val engines = listOf("https://www.google.com/search?q=", "https://duckduckgo.com/?q=", "https://www.bing.com/search?q=", "https://search.brave.com/search?q=")
    private val defaultFavs = listOf(
        Triple("Apple", "https://www.apple.com", "#555555"), Triple("iCloud", "https://www.icloud.com", "#0A84FF"),
        Triple("Google", "https://www.google.com", "#EA4335"), Triple("YouTube", "https://www.youtube.com", "#FF0000"),
        Triple("Wikipedia", "https://www.wikipedia.org", "#636366"), Triple("GitHub", "https://github.com", "#24292F"),
        Triple("Reddit", "https://www.reddit.com", "#FF5700"), Triple("News", "https://news.google.com", "#FF375F")
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun <T : View> id(i: Int): T = findViewById(i)

    @SuppressLint("ClickableViewAccessibility")
    private fun View.bounce(action: () -> Unit) {
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(.93f).scaleY(.93f).setDuration(p.d(80)).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(p.d(150)).setInterpolator(DecelerateInterpolator()).start()
            }
            false
        }
        setOnClickListener { action() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        container = id(R.id.container); urlField = id(R.id.urlField); progress = id(R.id.progress)
        startPage = id(R.id.startPage); favGrid = id(R.id.favGrid); bottomBar = id(R.id.bottomBar)
        overview = id(R.id.overview); btnBack = id(R.id.btnBack); btnForward = id(R.id.btnForward); gridRv = id(R.id.grid)
        gridRv.adapter = adapter; gridRv.layoutManager = GridLayoutManager(this, 2)

        btnBack.bounce { goBack() }
        btnForward.bounce { goForward() }
        id<View>(R.id.btnShare).bounce {
            if (!tab.isStart) startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, tab.web.url), "Share"))
        }
        id<View>(R.id.btnNew).bounce { newTab() }
        id<View>(R.id.btnAa).bounce { aaMenu(it) }
        id<View>(R.id.btnTabs).bounce { openOverview() }
        id<View>(R.id.btnReload).bounce { if (!tab.isStart) tab.web.reload() }
        id<View>(R.id.ovDone).bounce { closeOverview() }
        id<View>(R.id.ovSettings).bounce { startActivity(Intent(this, SettingsActivity::class.java)) }
        id<View>(R.id.ovPlus).bounce { tabs.add(Tab(makeWeb())); cur = tabs.lastIndex; closeOverview() }

        urlField.setOnEditorActionListener { v, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { go(v.text.toString()); v.clearFocus(); hideKb(); true } else false }
        urlField.setOnFocusChangeListener { _, f ->
            if (f) { urlField.gravity = Gravity.START or Gravity.CENTER_VERTICAL; urlField.setText(if (tab.isStart) "" else tab.web.url ?: ""); urlField.selectAll() }
            else { idleGravity(); updateUrl() }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    overview.visibility == View.VISIBLE -> closeOverview()
                    urlField.hasFocus() -> { urlField.clearFocus(); hideKb() }
                    !tab.isStart -> goBack()
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })
        applyPrefs()
        tabs.add(Tab(makeWeb())); show(0)
        intent?.data?.let { go(it.toString()) }
    }

    override fun onResume() { super.onResume(); if (tabs.isNotEmpty()) applyPrefs() }
    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); applyPrefs() }
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.data?.let { tabs.add(Tab(makeWeb())); cur = tabs.lastIndex; show(cur); go(it.toString()) }
    }

    // ---------- Customization ----------
    private fun idleGravity() { urlField.gravity = if (p.b("addrCenter", true)) Gravity.CENTER else Gravity.START or Gravity.CENTER_VERTICAL }

    private fun applyPrefs() {
        val topC = p.colorOr("tbColor", p.bg); val botC = p.colorOr("tbColor", p.bar); val pillC = p.colorOr("pillColor", p.pill)
        window.statusBarColor = topC; window.navigationBarColor = botC
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = ColorUtils.calculateLuminance(topC) > .5; isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(botC) > .5
        }
        id<View>(R.id.root).setBackgroundColor(p.bg); id<View>(R.id.topBar).setBackgroundColor(topC)
        urlField.apply {
            background = GradientDrawable().apply { cornerRadius = dp(p.i("radius", 12)).toFloat(); setColor(pillC) }
            layoutParams = layoutParams.apply { height = dp(p.i("addrH", 40)) }
            textSize = p.i("addrSize", 15).toFloat(); typeface = p.font; setTextColor(p.onColor(pillC)); setHintTextColor(p.sub)
            if (!hasFocus()) idleGravity()
        }
        val tint = ColorStateList.valueOf(p.colorOr("iconColor", p.accent))
        listOf(R.id.btnBack, R.id.btnForward, R.id.btnShare, R.id.btnNew, R.id.btnTabs, R.id.btnReload, R.id.ovPlus).forEach { id<ImageView>(it).imageTintList = tint }
        iconMap.forEach { (vid, pr) -> id<ImageView>(vid).setImageResource(if (p.i("iconStyle", 0) == 0) pr.second else pr.first) }
        id<TextView>(R.id.btnAa).apply {
            text = SpannableString("aA").apply { setSpan(RelativeSizeSpan(.72f), 0, 1, 0) }
            textSize = 21f; setTextColor(p.colorOr("iconColor", p.accent)); typeface = p.font
            visibility = if (p.b("showAa", true)) View.VISIBLE else View.GONE
        }
        id<View>(R.id.btnReload).visibility = if (p.b("showReload", true)) View.VISIBLE else View.GONE
        id<View>(R.id.btnShare).visibility = if (p.b("showShare", true)) View.VISIBLE else View.GONE
        id<View>(R.id.btnNew).visibility = if (p.b("showNew", true)) View.VISIBLE else View.GONE
        bottomBar.setBackgroundColor(botC)
        if (!barsHidden) bottomBar.layoutParams = bottomBar.layoutParams.apply { height = barH }
        (bottomBar.parent as LinearLayout).let { ll ->
            ll.removeView(bottomBar); ll.addView(bottomBar, if (p.i("tbPos", 0) == 1) 0 else ll.childCount)
        }
        progress.progressTintList = ColorStateList.valueOf(p.accent)
        progress.layoutParams = progress.layoutParams.apply { height = dp(p.i("progH", 2)) }
        startPage.setBackgroundColor(if (p.i("startBg", 0) == 1) ColorUtils.blendARGB(p.bg, p.accent, .08f) else p.bg)
        val stamp = p.s("wpStamp", "")
        val wpView = id<ImageView>(R.id.wallpaper)
        if (stamp != wpStamp) {
            wpStamp = stamp; val f = File(filesDir, "wallpaper.jpg")
            wpBmp = if (stamp.isNotEmpty() && f.exists()) BitmapFactory.decodeFile(f.path) else null
            wpView.setImageBitmap(wpBmp)
        }
        wpView.visibility = if (wpBmp != null) View.VISIBLE else View.GONE
        wpView.setColorFilter(PorterDuffColorFilter(Color.argb(p.i("wpDim", 25) * 255 / 100, 0, 0, 0), PorterDuff.Mode.SRC_ATOP))
        startFg = if (wpBmp != null) Color.WHITE else p.text
        id<TextView>(R.id.startTitle).apply {
            text = p.s("startTitle", "Favorites"); setTextColor(startFg); typeface = Typeface.create(p.font, Typeface.BOLD)
            visibility = if (p.b("showFavs", true)) View.VISIBLE else View.GONE
        }
        buildFavs()
        overview.setBackgroundColor(p.over)
        id<TextView>(R.id.overviewTitle).setTextColor(p.text)
        id<TextView>(R.id.ovDone).setTextColor(p.accent); id<TextView>(R.id.ovSettings).setTextColor(p.accent)
        (gridRv.layoutManager as GridLayoutManager).spanCount = p.i("tabCols", 2)
        adapter.notifyDataSetChanged()
        tabs.forEach { applyWeb(it.web) }
        if (tabs.isNotEmpty()) updateUi()
    }

    private fun applyWeb(w: WebView) = w.settings.run {
        javaScriptEnabled = p.b("js", true); textZoom = p.i("zoom", 100)
        userAgentString = if (p.b("desktop", false)) desktopUA else null
    }

    private fun loadFavs(): MutableList<Triple<String, String, String>> {
        val raw = p.s("favs", "")
        if (raw.isEmpty()) return defaultFavs.toMutableList()
        return raw.lines().mapNotNull { l -> l.split("\t").let { if (it.size == 3) Triple(it[0], it[1], it[2]) else null } }.toMutableList()
    }

    private fun saveFavs(l: List<Triple<String, String, String>>) =
        p.put("favs", if (l.isEmpty()) "\n" else l.joinToString("\n") { "${it.first}\t${it.second}\t${it.third}" })

    private val iconMap = mapOf(
        R.id.btnBack to (R.drawable.ic_back to R.drawable.ic_i_back), R.id.btnForward to (R.drawable.ic_forward to R.drawable.ic_i_forward),
        R.id.btnShare to (R.drawable.ic_share to R.drawable.ic_i_share), R.id.btnNew to (R.drawable.ic_add to R.drawable.ic_i_add),
        R.id.btnTabs to (R.drawable.ic_tabs to R.drawable.ic_i_tabs), R.id.btnReload to (R.drawable.ic_reload to R.drawable.ic_i_reload),
        R.id.ovPlus to (R.drawable.ic_add to R.drawable.ic_i_add)
    )

    private fun aaMenu(v: View) {
        val m = PopupMenu(this, v)
        m.menu.add(0, 1, 0, "Smaller text  (A−)"); m.menu.add(0, 2, 1, "Larger text  (A+)")
        m.menu.add(0, 3, 2, if (p.b("desktop", false)) "Request Mobile Website" else "Request Desktop Website")
        m.menu.add(0, 4, 3, "Settings")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> { p.put("zoom", (p.i("zoom", 100) - 10).coerceAtLeast(50)); tabs.forEach { t -> applyWeb(t.web) } }
                2 -> { p.put("zoom", (p.i("zoom", 100) + 10).coerceAtMost(200)); tabs.forEach { t -> applyWeb(t.web) } }
                3 -> { p.put("desktop", !p.b("desktop", false)); tabs.forEach { t -> applyWeb(t.web) }; if (!tab.isStart) tab.web.reload() }
                4 -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            true
        }
        m.show()
    }

    private val palette = listOf("#0A84FF", "#30D158", "#FF9F0A", "#FF375F", "#BF5AF2", "#64D2FF", "#636366")

    private fun favDialog(idx: Int) {
        val l = loadFavs(); val old = l.getOrNull(idx)
        var color = old?.third ?: palette[l.size % palette.size]
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), 0) }
        val name = EditText(this).apply { hint = "Name"; setText(old?.first ?: ""); setSingleLine() }
        val url = EditText(this).apply { hint = "Address"; setText(old?.second ?: ""); setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI }
        val row = LinearLayout(this)
        fun paint() { for (i in 0 until row.childCount) row.getChildAt(i).alpha = if (palette[i] == color) 1f else .35f }
        palette.forEach { c ->
            row.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(c)) }
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(10); topMargin = dp(14) }
                setOnClickListener { color = c; paint() }
            })
        }
        paint(); box.addView(name); box.addView(url); box.addView(row)
        val b = AlertDialog.Builder(this).setTitle(if (old == null) "New favorite" else "Edit favorite").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim().replace(Regex("[\t\n]"), " ")
                var u = url.text.toString().trim().replace(Regex("[\t\n]"), "")
                if (n.isNotEmpty() && u.isNotEmpty()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    val e = Triple(n, u, color); if (old == null) l.add(e) else l[idx] = e
                    saveFavs(l); buildFavs()
                }
            }.setNegativeButton("Cancel", null)
        if (old != null) b.setNeutralButton("Delete") { _, _ -> l.removeAt(idx); saveFavs(l); buildFavs() }
        b.show()
    }

    private fun buildFavs() {
        favGrid.removeAllViews()
        if (!p.b("showFavs", true)) return
        favGrid.columnCount = p.i("favCols", 4)
        val size = dp(p.i("favSize", 60))
        fun cell(label: String, glyph: String, fill: Int?, click: () -> Unit, long: (() -> Unit)?) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(12), 0, dp(12)) }
            cell.addView(TextView(this).apply {
                text = glyph; gravity = Gravity.CENTER; textSize = size / dp(1) * .4f; typeface = Typeface.create(p.font, Typeface.BOLD)
                setTextColor(if (fill == null) startFg else Color.WHITE)
                background = GradientDrawable().apply {
                    if (p.i("favShape", 0) == 0) shape = GradientDrawable.OVAL else cornerRadius = size * .26f
                    if (fill != null) setColor(fill) else setStroke(dp(2), startFg)
                }
                layoutParams = LinearLayout.LayoutParams(size, size)
            })
            cell.addView(TextView(this).apply { text = label; textSize = 12f; typeface = p.font; setTextColor(startFg); setPadding(0, dp(6), 0, 0) })
            cell.layoutParams = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)).apply { width = 0 }
            cell.bounce(click); long?.let { l -> cell.setOnLongClickListener { l(); true } }
            favGrid.addView(cell)
        }
        loadFavs().forEachIndexed { i, (n, u, c) -> cell(n, n.take(1), Color.parseColor(c), { go(u) }, { favDialog(i) }) }
        cell("Add", "+", null, { favDialog(-1) }, null)
    }

        // ---------- Navigation ----------
    private fun hideKb() = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlField.windowToken, 0)

    private fun go(input: String) {
        val q = input.trim(); if (q.isEmpty()) return
        val url = when {
            q.startsWith("http://") || q.startsWith("https://") -> q
            q.contains(".") && !q.contains(" ") -> "https://$q"
            else -> engines[p.i("engine", 0).coerceIn(0, 3)] + Uri.encode(q)
        }
        tab.isStart = false
        startPage.animate().alpha(0f).setDuration(p.d(150)).withEndAction { if (!tab.isStart) startPage.visibility = View.GONE }.start()
        tab.web.loadUrl(url); updateUi()
    }

    private fun goBack() {
        if (tab.isStart) return
        if (tab.web.canGoBack()) tab.web.goBack() else { tab.isStart = true; showStart(); updateUi() }
    }

    private fun goForward() {
        if (tab.isStart && tab.web.url != null) { tab.isStart = false; startPage.visibility = View.GONE; updateUi() }
        else if (tab.web.canGoForward()) tab.web.goForward()
    }

    private fun updateUi() {
        if (!urlField.hasFocus()) updateUrl()
        btnBack.alpha = if (tab.isStart) .35f else 1f
        btnForward.alpha = if ((tab.isStart && tab.web.url != null) || tab.web.canGoForward()) 1f else .35f
    }

    private fun updateUrl() {
        val u = if (tab.isStart) null else tab.web.url
        val lock = if (p.b("lock", true) && u?.startsWith("https") == true) "\uD83D\uDD12 " else ""
        urlField.setText(if (u == null) "" else lock + (Uri.parse(u).host?.removePrefix("www.") ?: u))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(): WebView = WebView(this).apply {
        settings.apply { domStorageEnabled = true; builtInZoomControls = true; displayZoomControls = false; loadWithOverviewMode = true; useWideViewPort = true; mediaPlaybackRequiresUserGesture = false }
        applyWeb(this)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) {
                if (v === tab.web) { progress.animate().cancel(); progress.progress = 0; progress.alpha = 1f; updateUi() }
            }
            override fun onPageFinished(v: WebView, url: String?) { if (v === tab.web) updateUi() }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.scheme in listOf("http", "https", "about", "file", "data", "blob")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Exception) {}
                return true
            }
        }
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, pr: Int) {
                if (v !== tab.web) return
                ObjectAnimator.ofInt(progress, "progress", pr * 10).setDuration(p.d(200)).start()
                if (pr >= 100) progress.animate().alpha(0f).setStartDelay(p.d(250)).setDuration(p.d(300)).start()
            }
            override fun onReceivedTitle(v: WebView, title: String?) { tabs.firstOrNull { it.web === v }?.title = title ?: "Untitled" }
        }
        setOnScrollChangeListener { _, _, y, _, oy ->
            if (p.b("autohide", true)) { if (y - oy > 14) bars(true) else if (oy - y > 14) bars(false) }
        }
        setDownloadListener { url, ua, cd, mime, _ ->
            try {
                val r = DownloadManager.Request(Uri.parse(url)).addRequestHeader("User-Agent", ua)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
                Toast.makeText(this@MainActivity, "Downloading…", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {}
        }
    }

    private fun bars(hide: Boolean) {
        if (hide == barsHidden) return
        barsHidden = hide
        ValueAnimator.ofInt(bottomBar.layoutParams.height, if (hide) 0 else barH).apply {
            duration = p.d(200)
            addUpdateListener { bottomBar.layoutParams.height = it.animatedValue as Int; bottomBar.requestLayout() }
        }.start()
    }

    // ---------- Tabs ----------
    private fun newTab() { tabs.add(Tab(makeWeb())); show(tabs.lastIndex) }

    private fun show(i: Int) {
        cur = i; bars(false)
        while (container.childCount > 1) container.removeViewAt(0)
        (tab.web.parent as? ViewGroup)?.removeView(tab.web)
        container.addView(tab.web, 0, FrameLayout.LayoutParams(-1, -1))
        if (tab.isStart) showStart() else startPage.visibility = View.GONE
        updateUi()
        container.alpha = .6f; container.translationY = dp(6).toFloat()
        container.animate().alpha(1f).translationY(0f).setDuration(p.d(200)).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun showStart() {
        startPage.animate().cancel(); startPage.visibility = View.VISIBLE; startPage.alpha = 0f
        startPage.animate().alpha(1f).setDuration(p.d(200)).start()
        for (i in 0 until favGrid.childCount) favGrid.getChildAt(i).apply {
            alpha = 0f; translationY = dp(8).toFloat()
            animate().alpha(1f).translationY(0f).setStartDelay(p.d(25L * i)).setDuration(p.d(260)).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun captureThumb() {
        val w = container.width; val h = container.height; if (w == 0 || h == 0) return
        try {
            val bmp = Bitmap.createBitmap(w / 3, h / 3, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp); c.scale(1 / 3f, 1 / 3f); c.drawColor(p.bg); container.draw(c); tab.thumb = bmp
        } catch (_: Throwable) {}
    }

    private fun updateCount() { id<TextView>(R.id.overviewTitle).text = "${tabs.size} Tab${if (tabs.size == 1) "" else "s"}" }

    private fun openOverview() {
        hideKb(); captureThumb(); updateCount(); adapter.notifyDataSetChanged()
        overview.apply {
            visibility = View.VISIBLE; alpha = 0f; scaleX = 1.03f; scaleY = 1.03f
            animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(p.d(220)).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closeOverview() {
        overview.animate().alpha(0f).scaleX(1.03f).scaleY(1.03f).setDuration(p.d(160))
            .withEndAction { overview.visibility = View.GONE; show(cur) }.start()
    }

    private fun closeTab(i: Int) {
        if (i < 0) return
        tabs.removeAt(i).web.destroy()
        if (tabs.isEmpty()) { tabs.add(Tab(makeWeb())); cur = 0; adapter.notifyDataSetChanged() }
        else { if (i < cur) cur-- else if (cur >= tabs.size) cur = tabs.lastIndex; adapter.notifyItemRemoved(i) }
        updateCount()
    }

    inner class TabAdapter : RecyclerView.Adapter<TabAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val card = v as MaterialCardView; val img: ImageView = v.findViewById(R.id.thumb)
            val title: TextView = v.findViewById(R.id.title); val close: TextView = v.findViewById(R.id.close)
        }
        override fun onCreateViewHolder(pa: ViewGroup, t: Int) = VH(layoutInflater.inflate(R.layout.item_tab, pa, false))
        override fun getItemCount() = tabs.size
        override fun onBindViewHolder(h: VH, i: Int) {
            h.title.text = tabs[i].title; h.title.setTextColor(p.text); h.title.typeface = p.font
            h.close.setTextColor(p.sub); h.img.setImageBitmap(tabs[i].thumb); h.img.setBackgroundColor(p.over)
            h.img.layoutParams = h.img.layoutParams.apply { height = dp(p.i("thumbH", 200)) }
            h.card.setCardBackgroundColor(p.card); h.card.strokeColor = p.accent
            h.card.strokeWidth = if (i == cur) dp(3) else 0
            h.card.setOnClickListener { cur = h.bindingAdapterPosition; closeOverview() }
            h.close.setOnClickListener { closeTab(h.bindingAdapterPosition) }
        }
    }
}
